﻿$(document).ready(function() {
    var currentUrl = window.location.pathname;
    $('.nav-link').each(function() {
        var href = $(this).attr('href');
        if (currentUrl === href) {
            $(this).addClass('active');
        }
    });
});