using System.ComponentModel.DataAnnotations;

namespace mero_school.Models;

public class LessonModel
{
    [Key] public string LessonId { get; set; }

    [Required] public Int16 LessonNumber { get; set; }

    [Required] public string CourseId { get; set; }

    [Required] public string LessonContent { get; set; }
}