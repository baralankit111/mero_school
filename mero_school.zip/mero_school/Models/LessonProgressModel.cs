using System.ComponentModel.DataAnnotations;

namespace mero_school.Models;

public enum LessonStatusEnum
{
    NotStarted = 0,
    InProgress = 1,
    Completed = 2
}

public class LessonProgressModel
{
    [Key] public string LessonProgressId { get; set; }

    [Required] public string LessonId { get; set; }

    [Required] public string EnrolmentId { get; set; }

    [Required] public LessonStatusEnum LessonStatus { get; set; }
}