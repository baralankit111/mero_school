using System.ComponentModel.DataAnnotations;

namespace mero_school.Models;

public class StudentQueryModel
{
    [Key] public string StudentQueryId { get; set; }

    [Required] public string EnrolmentId { get; set; }

    [Required] public string Question { get; set; }
}