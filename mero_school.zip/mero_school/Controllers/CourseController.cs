using mero_school.Models;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace mero_school.Controllers;

public class CourseController : Controller
{
    public IActionResult Index(string searchQuery, string sortBy, string sortOrder = "ASC")
    {
        string queryString = "SELECT * FROM COURSE";
        if (!string.IsNullOrEmpty(searchQuery))
        {
            queryString += $" WHERE UPPER(COURSE_TITLE) LIKE UPPER('%{searchQuery}%')";
        }

        if (!string.IsNullOrEmpty(sortBy))
        {
            queryString += $" ORDER BY {sortBy} {sortOrder}";
        }
        else
        {
            queryString += $" ORDER BY COURSE_TITLE {sortOrder}";
        }

        List<CourseModel> courses = new List<CourseModel>();
        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand command = new OracleCommand(queryString, connection);
        command.Connection.Open();

        OracleDataReader reader = command.ExecuteReader();
        while (reader.Read())
        {
            CourseModel course = new CourseModel();
            course.CourseId = reader.GetString(0);
            course.CourseTitle = reader.GetString(1);
            course.CourseDescription = reader.GetString(2);
            courses.Add(course);
        }

        reader.Dispose();

        return View(courses);
    }

    [HttpPost]
    public IActionResult Create(CourseModel course)
    {
        course.CourseId = Guid.NewGuid().ToString();

        DbManager.Execute(
            $"INSERT INTO COURSE (COURSE_ID, COURSE_TITLE, COURSE_DESCRIPTION) VALUES ('{course.CourseId}', '{course.CourseTitle}', '{course.CourseDescription}')");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(CourseModel course)
    {
        Console.WriteLine(course.CourseId);
        Console.WriteLine(course.CourseTitle);
        Console.WriteLine(course.CourseDescription);
        DbManager.Execute(
            $"UPDATE COURSE SET COURSE_TITLE = '{course.CourseTitle}', COURSE_DESCRIPTION = '{course.CourseDescription}' WHERE COURSE_ID = '{course.CourseId}'");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM COURSE WHERE COURSE_ID = '{id}'");
        return RedirectToAction("Index");
    }
}