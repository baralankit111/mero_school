using mero_school.Models;
using mero_school.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace mero_school.Controllers;

public class StudentController : Controller
{
    public IActionResult Index(string searchQuery, string sortBy, string sortOrder = "ASC")
    {
        string queryString = "SELECT * FROM STUDENT";
        if (!string.IsNullOrEmpty(searchQuery))
        {
            queryString += $" WHERE UPPER(STUDENT_NAME) LIKE UPPER('%{searchQuery}%')";
        }

        if (!string.IsNullOrEmpty(sortBy))
        {
            queryString += $" ORDER BY {sortBy} {sortOrder}";
        }
        else
        {
            queryString += $" ORDER BY STUDENT_NAME {sortOrder}";
        }

        StudentViewModel studentViewModel = new StudentViewModel()
        {
            Countries = new List<CountryModel>(),
            Students = new List<StudentModel>()
        };

        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand command = new OracleCommand(queryString, connection);
        command.Connection.Open();

        OracleDataReader reader = command.ExecuteReader();
        while (reader.Read())
        {
            StudentModel student = new StudentModel();
            student.StudentId = reader.GetString(0);
            student.StudentName = reader.GetString(1);
            student.CountryId = reader.GetString(2);
            student.StudentEmail = reader.GetString(3);
            student.StudentContact = reader.GetString(4);
            student.StudentDob = reader.GetDateTime(5);
            studentViewModel.Students.Add(student);
        }

        reader.Dispose();

        queryString = "SELECT * FROM COUNTRY";

        using OracleConnection newConnection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand studentCommand = new OracleCommand(queryString, newConnection);
        studentCommand.Connection.Open();

        OracleDataReader studentReader = studentCommand.ExecuteReader();

        while (studentReader.Read())
        {
            CountryModel country = new CountryModel();
            country.CountryId = studentReader.GetString(0);
            country.CountryName = studentReader.GetString(1);
            country.CountryZipCode = studentReader.GetInt32(2);

            studentViewModel.Countries.Add(country);
        }

        studentReader.Dispose();

        return View(studentViewModel);
    }

    [HttpPost]
    public IActionResult Create(StudentModel student)
    {
        student.StudentId = Guid.NewGuid().ToString();

        string queryString =
            $"INSERT INTO STUDENT (STUDENT_ID, STUDENT_NAME, COUNTRY_ID, STUDENT_EMAIL, STUDENT_CONTACT, STUDENT_DOB) VALUES ('{student.StudentId}', '{student.StudentName}', '{student.CountryId}', '{student.StudentEmail}', '{student.StudentContact}', TO_DATE('{student.StudentDob:yyyy-MM-dd}', 'YYYY-MM-DD'))";

        DbManager.Execute(queryString);

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(StudentModel student)
    {
        DbManager.Execute(
            $"UPDATE STUDENT SET STUDENT_NAME = '{student.StudentName}', COUNTRY_ID = '{student.CountryId}', STUDENT_EMAIL = '{student.StudentEmail}', STUDENT_CONTACT = '{student.StudentContact}', STUDENT_DOB = TO_DATE('{student.StudentDob:yyyy-MM-dd}', 'YYYY-MM-DD') WHERE STUDENT_ID = '{student.StudentId}'");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM STUDENT WHERE STUDENT_ID = '{id}'");
        return RedirectToAction("Index");
    }
}