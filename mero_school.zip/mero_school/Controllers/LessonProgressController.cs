using mero_school.Models;
using mero_school.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace mero_school.Controllers;

public class LessonProgressController : Controller
{
    public IActionResult Index()
    {
        LessonProgressViewModel viewModel = new LessonProgressViewModel()
        {
            Lessons = new List<LessonModel>(),
            Enrolments = new List<EnrolmentModel>(),
            Courses = new List<CourseModel>(),
            Students = new List<StudentModel>(),
            LessonProgresses = new List<LessonProgressModel>()
        };

        string queryString;
        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        connection.Open();

        // Lesson
        queryString = "SELECT * FROM LESSON";
        
        OracleCommand getLessonListCommand = new OracleCommand(queryString, connection);
        OracleDataReader lessonReader = getLessonListCommand.ExecuteReader();
        while (lessonReader.Read())
        {
            LessonModel lesson = new LessonModel();
            lesson.LessonId = lessonReader.GetString(0);
            lesson.LessonNumber = lessonReader.GetInt16(1);
            lesson.CourseId = lessonReader.GetString(2);
            lesson.LessonContent = lessonReader.GetString(3);
            viewModel.Lessons.Add(lesson);
        }

        lessonReader.Dispose();

        // Enrolment
        queryString = "SELECT * FROM ENROLMENT";

        OracleCommand getEnrolmentListCommand = new OracleCommand(queryString, connection);
        OracleDataReader enrolmentReader = getEnrolmentListCommand.ExecuteReader();
        while (enrolmentReader.Read())
        {
            EnrolmentModel enrolment = new EnrolmentModel();
            enrolment.EnrolmentId = enrolmentReader.GetString(0);
            enrolment.StudentId = enrolmentReader.GetString(1);
            enrolment.CourseId = enrolmentReader.GetString(2);
            enrolment.EnrolmentDate = enrolmentReader.GetDateTime(3);
            viewModel.Enrolments.Add(enrolment);
        }

        enrolmentReader.Dispose();

        // Course
        queryString = "SELECT * FROM COURSE";

        OracleCommand getCourseListCommand = new OracleCommand(queryString, connection);
        OracleDataReader courseReader = getCourseListCommand.ExecuteReader();
        while (courseReader.Read())
        {
            CourseModel course = new CourseModel();
            course.CourseId = courseReader.GetString(0);
            course.CourseTitle = courseReader.GetString(1);
            course.CourseDescription = courseReader.GetString(1);
            viewModel.Courses.Add(course);
        }

        courseReader.Dispose();


        // Student
        queryString = "SELECT * FROM STUDENT";

        OracleCommand getStudentListCommand = new OracleCommand(queryString, connection);
        OracleDataReader studentReader = getStudentListCommand.ExecuteReader();
        while (studentReader.Read())
        {
            StudentModel student = new StudentModel();
            student.StudentId = studentReader.GetString(0);
            student.StudentName = studentReader.GetString(1);
            student.CountryId = studentReader.GetString(2);
            student.StudentEmail = studentReader.GetString(3);
            student.StudentContact = studentReader.GetString(4);
            student.StudentDob = studentReader.GetDateTime(5);
            viewModel.Students.Add(student);
        }

        studentReader.Dispose();

        // Lesson Progress
        queryString = "SELECT * FROM LESSONPROGRESS";

        OracleCommand getLessonProgressListCommand = new OracleCommand(queryString, connection);
        OracleDataReader lessonProgressReader = getLessonProgressListCommand.ExecuteReader();
        while (lessonProgressReader.Read())
        {
            LessonProgressModel lessonProgress = new LessonProgressModel();
            lessonProgress.LessonProgressId = lessonProgressReader.GetString(0);
            lessonProgress.LessonId = lessonProgressReader.GetString(1);
            lessonProgress.EnrolmentId = lessonProgressReader.GetString(2);

            switch (lessonProgressReader.GetString(3))
            {
                case "NOT_STARTED":
                    lessonProgress.LessonStatus = LessonStatusEnum.NotStarted;
                    break;
                case "ON_PROGRESS":
                    lessonProgress.LessonStatus = LessonStatusEnum.InProgress;
                    break;
                case "COMPLETED":
                    lessonProgress.LessonStatus = LessonStatusEnum.Completed;
                    break;
                default:
                    lessonProgress.LessonStatus = LessonStatusEnum.NotStarted;
                    break;
            }

            viewModel.LessonProgresses.Add(lessonProgress);
        }

        lessonProgressReader.Dispose();

        return View(viewModel);
    }

    [HttpPost]
    public IActionResult Create(LessonProgressModel progress)
    {
        string lessonStatus;

        if (progress.LessonStatus == LessonStatusEnum.NotStarted)
        {
            lessonStatus = "NOT_STARTED";
        }
        else if (progress.LessonStatus == LessonStatusEnum.InProgress)
        {
            lessonStatus = "ON_PROGRESS";
        }
        else
        {
            lessonStatus = "COMPLETED";
        }

        progress.LessonProgressId = Guid.NewGuid().ToString();

        DbManager.Execute(
            $"INSERT INTO LESSONPROGRESS (LESSON_PROGRESS_ID, LESSON_ID, ENROLMENT_ID, LESSON_STATUS) VALUES ('{progress.LessonProgressId}', '{progress.LessonId}', '{progress.EnrolmentId}', '{lessonStatus}')");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(LessonProgressModel progress)
    {
        string lessonStatus;

        if (progress.LessonStatus == LessonStatusEnum.NotStarted)
        {
            lessonStatus = "NOT_STARTED";
        }
        else if (progress.LessonStatus == LessonStatusEnum.InProgress)
        {
            lessonStatus = "ON_PROGRESS";
        }
        else
        {
            lessonStatus = "COMPLETED";
        }

        Console.WriteLine(progress.LessonStatus);
        Console.WriteLine(lessonStatus);

        DbManager.Execute(
            $"UPDATE LESSONPROGRESS SET LESSON_ID = '{progress.LessonId}', ENROLMENT_ID = '{progress.EnrolmentId}', LESSON_STATUS = '{lessonStatus}' WHERE LESSON_PROGRESS_ID = '{progress.LessonProgressId}'");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM LESSONPROGRESS WHERE LESSON_PROGRESS_ID = '{id}'");
        return RedirectToAction("Index");
    }
}