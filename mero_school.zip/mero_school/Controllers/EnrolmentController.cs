using mero_school.Models;
using mero_school.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace mero_school.Controllers;

public class EnrolmentController : Controller
{
    public IActionResult Index(string searchQuery, string sortBy, string sortOrder = "ASC")
    {
        string queryString =
            "SELECT e.ENROLMENT_ID, s.STUDENT_ID, s.STUDENT_NAME, c.COURSE_ID, c.COURSE_TITLE, e.ENROL_DATE FROM Enrolment e JOIN Student s ON e.STUDENT_ID = s.STUDENT_ID JOIN Course c ON e.COURSE_ID = c.COURSE_ID";

        if (!string.IsNullOrEmpty(searchQuery))
        {
            queryString +=
                $"  WHERE UPPER(s.STUDENT_NAME) LIKE UPPER('%{searchQuery}%') OR UPPER(c.COURSE_TITLE) LIKE UPPER('%{searchQuery}%')";
        }

        if (!string.IsNullOrEmpty(sortBy))
        {
            queryString += $" ORDER BY {sortBy} {sortOrder}";
        }
        else
        {
            queryString += $" ORDER BY ENROL_DATE {sortOrder}";
        }

        EnrolmentViewModel viewModel = new EnrolmentViewModel()
        {
            Students = new List<StudentModel>(),
            Courses = new List<CourseModel>(),
            Enrolments = new List<JoinedEnrolment>()
        };

        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand command = new OracleCommand(queryString, connection);
        command.Connection.Open();

        OracleDataReader reader = command.ExecuteReader();
        while (reader.Read())
        {
            JoinedEnrolment enrolment = new JoinedEnrolment();
            enrolment.EnrolmentId = reader.GetString(0);
            enrolment.StudentId = reader.GetString(1);
            enrolment.StudentName = reader.GetString(2);
            enrolment.CourseId = reader.GetString(3);
            enrolment.CourseTitle = reader.GetString(4);
            enrolment.EnrolmentDate = reader.GetDateTime(5);
            viewModel.Enrolments.Add(enrolment);
        }

        reader.Dispose();

        // Students
        queryString = "SELECT * FROM STUDENT";

        using OracleConnection stdConnection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand stdCommand = new OracleCommand(queryString, stdConnection);
        stdCommand.Connection.Open();
        OracleDataReader stdReader = stdCommand.ExecuteReader();
        while (stdReader.Read())
        {
            StudentModel student = new StudentModel();
            student.StudentId = stdReader.GetString(0);
            student.StudentName = stdReader.GetString(1);
            student.CountryId = stdReader.GetString(2);
            student.StudentEmail = stdReader.GetString(3);
            student.StudentContact = stdReader.GetString(4);
            student.StudentDob = stdReader.GetDateTime(5);
            viewModel.Students.Add(student);
        }

        stdReader.Dispose();

        // Courses
        queryString = "SELECT * FROM COURSE";

        using OracleConnection courseConnection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand courseCommand = new OracleCommand(queryString, courseConnection);
        courseCommand.Connection.Open();
        OracleDataReader courseReader = courseCommand.ExecuteReader();
        while (courseReader.Read())
        {
            CourseModel course = new CourseModel();
            course.CourseId = courseReader.GetString(0);
            course.CourseTitle = courseReader.GetString(1);
            course.CourseDescription = courseReader.GetString(2);
            viewModel.Courses.Add(course);
        }

        courseReader.Dispose();

        return View(viewModel);
    }

    [HttpPost]
    public IActionResult Create(EnrolmentModel enrolment)
    {
        enrolment.EnrolmentId = Guid.NewGuid().ToString();

        DbManager.Execute(
            $"INSERT INTO ENROLMENT (ENROLMENT_ID, STUDENT_ID, COURSE_ID, ENROL_DATE) VALUES ('{enrolment.EnrolmentId}', '{enrolment.StudentId}', '{enrolment.CourseId}', TO_DATE('{enrolment.EnrolmentDate:yyyy-MM-dd}', 'YYYY-MM-DD'))");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(EnrolmentModel enrolment)
    {
        DbManager.Execute(
            $"UPDATE ENROLMENT SET STUDENT_ID = '{enrolment.StudentId}', COURSE_ID = '{enrolment.CourseId}', ENROL_DATE = TO_DATE('{enrolment.EnrolmentDate:yyyy-MM-dd}', 'YYYY-MM-DD') WHERE ENROLMENT_ID = '{enrolment.EnrolmentId}'");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM ENROLMENT WHERE ENROLMENT_ID = '{id}'");
        return RedirectToAction("Index");
    }
}