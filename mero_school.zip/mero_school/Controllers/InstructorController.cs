using mero_school.Models;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace mero_school.Controllers;

public class InstructorController : Controller
{
    public IActionResult Index(string searchQuery, string sortBy, string sortOrder = "ASC")
    {
        string queryString = "SELECT * FROM INSTRUCTOR";
        if (!string.IsNullOrEmpty(searchQuery))
        {
            queryString += $" WHERE UPPER(INSTRUCTOR_NAME) LIKE UPPER('%{searchQuery}%')";
        }

        if (!string.IsNullOrEmpty(sortBy))
        {
            queryString += $" ORDER BY {sortBy} {sortOrder}";
        }
        else
        {
            queryString += $" ORDER BY INSTRUCTOR_NAME {sortOrder}";
        }

        List<InstructorModel> instructors = new List<InstructorModel>();
        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand command = new OracleCommand(queryString, connection);
        command.Connection.Open();

        OracleDataReader reader = command.ExecuteReader();
        while (reader.Read())
        {
            InstructorModel instructor = new InstructorModel();
            instructor.InstructorId = reader.GetString(0);
            instructor.InstructorName = reader.GetString(1);
            instructor.InstructorEmail = reader.GetString(2);
            instructors.Add(instructor);
        }

        reader.Dispose();

        return View(instructors);
    }

    [HttpPost]
    public IActionResult Create(InstructorModel instructor)
    {
        instructor.InstructorId = Guid.NewGuid().ToString();

        DbManager.Execute(
            $"INSERT INTO INSTRUCTOR (INSTRUCTOR_ID, INSTRUCTOR_NAME, INSTRUCTOR_EMAIL) VALUES ('{instructor.InstructorId}', '{instructor.InstructorName}', '{instructor.InstructorEmail}')");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(InstructorModel instructor)
    {
        Console.WriteLine(instructor.InstructorId);
        Console.WriteLine(instructor.InstructorName);
        Console.WriteLine(instructor.InstructorEmail);
        DbManager.Execute(
            $"UPDATE INSTRUCTOR SET INSTRUCTOR_NAME = '{instructor.InstructorName}', INSTRUCTOR_EMAIL = '{instructor.InstructorEmail}' WHERE INSTRUCTOR_ID = '{instructor.InstructorId}'");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM INSTRUCTOR WHERE INSTRUCTOR_ID = '{id}'");
        return RedirectToAction("Index");
    }
}