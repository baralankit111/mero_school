using mero_school.Models;

namespace mero_school.ViewModels;

public class LessonViewModel
{
    public List<LessonModel> Lessons { get; set; }
    public List<CourseModel> Courses { get; set; }
}