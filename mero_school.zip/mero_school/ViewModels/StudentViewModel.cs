using mero_school.Models;

namespace mero_school.ViewModels;

public class StudentViewModel
{
    public List<StudentModel> Students { get; set; }
    public List<CountryModel> Countries { get; set; }
}