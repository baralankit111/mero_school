using mero_school.Models;

namespace mero_school.ViewModels;

public class FeedbackViewModel
{
    public List<FeedbackModel> Feedbacks { get; set; }
    public List<CourseInstructorModel> CourseInstructors { get; set; }
    public List<EnrolmentModel> Enrolments { get; set; }
    public List<StudentModel> Students { get; set; }

    public List<CourseModel> Courses { get; set; }
    public List<StudentQueryModel> StudentQueries { get; set; }
    public List<InstructorModel> Instructors { get; set; }
}