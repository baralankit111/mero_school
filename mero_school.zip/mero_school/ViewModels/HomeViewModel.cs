using mero_school.Models;

namespace mero_school.ViewModels;

public class HomeViewModel
{
    public int CourseCount { get; set; }
    public int StudentCount { get; set; }
    public int InstructorCount { get; set; }

    public List<CourseModel> MonthlyTopCourses { get; set; }
}