using mero_school.Models;

namespace mero_school.ViewModels;

public class LessonProgressViewModel
{
    public List<LessonProgressModel> LessonProgresses;
    public List<LessonModel> Lessons;
    public List<EnrolmentModel> Enrolments;
    public List<StudentModel> Students;
    public List<CourseModel> Courses;
}