using mero_school.Models;

namespace mero_school.ViewModels;

public class TopCourse : CourseModel
{
    public int EnrolCount { get; set; }
}

public class MonthlyEnrolInsight
{
    public string MonthNumber { get; set; }
    public string MonthName { get; set; }
    public int EnrolCount { get; set; }
}

public class DashboardViewModel
{
    public int TotalStudents { get; set; }
    public int TotalEnrolments { get; set; }
    public int TotalInstructors { get; set; }
    public int TotalCourses { get; set; }

    public List<TopCourse> TopCourses { get; set; }
    public List<MonthlyEnrolInsight> MonthlyEnrolInsights { get; set; }
}